#ifndef SCHEME_H_INCLUDED
#define SCHEME_H_INCLUDED
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Scheme : public vector<string>{

private:


public:
    Scheme();

};

#endif // SCHEME_H_INCLUDED
