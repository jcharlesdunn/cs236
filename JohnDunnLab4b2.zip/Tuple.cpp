#include "Tuple.h"

Tuple::Tuple()
{}
