#ifndef TUPLE_H_INCLUDED
#define TUPLE_H_INCLUDED
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Tuple : public vector<string>{

private:


public:
    Tuple();
};


#endif // TUPLE_H_INCLUDED
